cp -f D:/FPGA/ad9226_fft_spi_7.20/prj/ip_fft/ip_fft/simulation/submodules/ip_fft_fft_ii_0_1n4096cos.hex ./
cp -f D:/FPGA/ad9226_fft_spi_7.20/prj/ip_fft/ip_fft/simulation/submodules/ip_fft_fft_ii_0_2n4096cos.hex ./
cp -f D:/FPGA/ad9226_fft_spi_7.20/prj/ip_fft/ip_fft/simulation/submodules/ip_fft_fft_ii_0_1n4096sin.hex ./
cp -f D:/FPGA/ad9226_fft_spi_7.20/prj/ip_fft/ip_fft/simulation/submodules/ip_fft_fft_ii_0_3n4096cos.hex ./
cp -f D:/FPGA/ad9226_fft_spi_7.20/prj/ip_fft/ip_fft/simulation/submodules/ip_fft_fft_ii_0_2n4096sin.hex ./
cp -f D:/FPGA/ad9226_fft_spi_7.20/prj/ip_fft/ip_fft/simulation/submodules/ip_fft_fft_ii_0_3n4096sin.hex ./
