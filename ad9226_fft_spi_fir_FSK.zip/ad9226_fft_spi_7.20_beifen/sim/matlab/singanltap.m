data= stp1autosignaltap0;
plot(data);